<?php $__env->startSection('contenido'); ?>
<div class="container mx-auto px-4 py-6">
    <h1 class="text-2xl font-semibold">Condiciones de uso</h1>
    <p>Aquí están las condiciones de uso de nuestros servicios.</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Raul\Documents\GitHub\amakha_paris_bolivia\resources\views/Web/Partials/footer/condiciones-uso.blade.php ENDPATH**/ ?>