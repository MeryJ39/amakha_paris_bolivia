<?php $__env->startSection('titulo', 'Checkout'); ?>
<?php $__env->startSection('contenido'); ?>
<div class="container mx-auto my-5 py-3 bg-white shadow-lg rounded-lg">
    <h2 class="text-center text-2xl font-bold mb-6">Resumen de tu compra</h2>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
            <?php $__currentLoopData = $cartCollection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex justify-between border-b py-3">
                <span><?php echo e($item->name); ?> (<?php echo e($item->quantity); ?>)</span>
                <span>$<?php echo e($item->price); ?></span>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div>
            <h3 class="text-xl font-bold">Total a pagar: $<?php echo e($totalAmount); ?></h3>

            <form action="<?php echo e(route('checkout.process')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="total_amount" value="<?php echo e($totalAmount); ?>">
                <input type="hidden" name="cart_items" value="<?php echo e(json_encode($cartCollection)); ?>">
                <button type="submit" class="mt-5 bg-blue-500 text-white px-4 py-2 rounded">Realizar Pago</button>
            </form>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Raul\Desktop\ecommerce_platform\resources\views/Web/Checkout/index.blade.php ENDPATH**/ ?>