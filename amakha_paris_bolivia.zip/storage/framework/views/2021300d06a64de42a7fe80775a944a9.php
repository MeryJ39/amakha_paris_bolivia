<?php $__env->startSection('contenido'); ?>
<div class="container mx-auto px-4 py-6">
    <h1 class="text-2xl font-semibold">Contáctenos</h1>
    <p>Aquí va la información de contacto y un formulario si lo deseas.</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Raul\Documents\GitHub\amakha_paris_bolivia\resources\views/Web/Partials/footer/contactenos.blade.php ENDPATH**/ ?>