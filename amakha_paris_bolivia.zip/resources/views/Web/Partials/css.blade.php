<link rel="stylesheet" href="{{URL::asset('FrontEnd/css/bootstrap.min.css')}}">
          <link rel="stylesheet" href="{{URL::asset('FrontEnd/css/mdb.min.css')}}">
          <link rel="stylesheet" href="{{URL::asset('FrontEnd/css/fontawesome.min.css')}}">
          <link rel="stylesheet" href="{{URL::asset('FrontEnd/css/solid.min.css')}}">
          <link rel="stylesheet" href="{{URL::asset('FrontEnd/css/estilos.css')}}">
