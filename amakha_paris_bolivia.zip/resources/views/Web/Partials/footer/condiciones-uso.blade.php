@extends('welcome')

@section('contenido')
<div class="container mx-auto px-4 py-6">
    <h1 class="text-2xl font-semibold">Condiciones de uso</h1>
    <p>Aquí están las condiciones de uso de nuestros servicios.</p>
</div>
@endsection
