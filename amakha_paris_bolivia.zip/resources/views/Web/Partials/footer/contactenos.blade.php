@extends('welcome')

@section('contenido')
<div class="container mx-auto px-4 py-6">
    <h1 class="text-2xl font-semibold">Contáctenos</h1>
    <p>Aquí va la información de contacto y un formulario si lo deseas.</p>
</div>
@endsection
