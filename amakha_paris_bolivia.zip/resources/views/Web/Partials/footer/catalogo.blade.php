@extends('welcome')

@section('contenido')
<div class="container mx-auto px-4 py-6">
    <h1 class="text-2xl font-semibold">Nuestro catálogo</h1>
    <p>Aquí va una descripción de nuestro catálogo de productos.</p>
</div>
@endsection
