@extends('welcome')

@section('contenido')
<div class="container mx-auto px-4 py-6">
    <h1 class="text-2xl font-semibold">Mapa del sitio</h1>
    <p>Aquí va el mapa del sitio y sus enlaces relevantes.</p>
</div>
@endsection
