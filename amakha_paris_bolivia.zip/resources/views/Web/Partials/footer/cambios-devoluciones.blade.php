@extends('welcome')

@section('contenido')
<div class="container mx-auto px-4 py-6">
    <h1 class="text-2xl font-semibold">Cambios Devoluciones/Reembolsos</h1>
    <p>Aquí se detalla nuestra política de cambios y devoluciones.</p>
</div>
@endsection
