<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\Filament\AdminPanelProvider::class,
    Darryldecode\Cart\CartServiceProvider::class,
];
